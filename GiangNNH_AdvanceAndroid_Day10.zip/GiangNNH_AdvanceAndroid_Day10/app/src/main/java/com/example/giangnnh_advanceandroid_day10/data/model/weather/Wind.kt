package com.example.giangnnh_advanceandroid_day10.data.model.weather

data class Wind(
    val deg: Int,
    val speed: Double
)
package com.example.giangnnh_advanceandroid_day10.data.model.city

data class City(val id: Int = 0, val name: String = "")
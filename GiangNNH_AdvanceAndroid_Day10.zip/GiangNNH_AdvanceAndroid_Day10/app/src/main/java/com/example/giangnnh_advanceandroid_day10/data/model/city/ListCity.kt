package com.example.giangnnh_advanceandroid_day10.data.model.city

data class ListCity(val data: List<City>? = null)
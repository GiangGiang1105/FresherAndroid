package com.example.giangnnh_advanceandroid_day10.data.model.weather

data class Clouds(
    val all: Int
)
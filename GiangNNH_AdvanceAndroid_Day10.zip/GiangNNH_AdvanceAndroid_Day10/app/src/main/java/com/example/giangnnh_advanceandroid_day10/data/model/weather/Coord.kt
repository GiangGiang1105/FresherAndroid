package com.example.giangnnh_advanceandroid_day10.data.model.weather

data class Coord(
    val lat: Double,
    val lon: Double
)